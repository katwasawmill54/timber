# 🪵 TIMBER BILL

Professional billing app for sawmill owners. Built with React + Vite + Firebase.

---

## Setup (10 minutes)

### 1. Install dependencies
```bash
npm install
```

### 2. Create Firebase project
1. Go to [console.firebase.google.com](https://console.firebase.google.com)
2. Click **Add Project** → name it `timber-bill` → Create
3. Go to **Authentication** → Get Started → Enable **Google** sign-in
4. Go to **Firestore Database** → Create database → **Start in test mode** → Region: `asia-south1`
5. Go to **Project Settings** (gear icon) → **Your apps** → click **</>** Web
6. Register app as `timber-bill` → Copy the config

### 3. Create .env file
Copy `.env.example` to `.env` and fill in your Firebase config:
```
VITE_FIREBASE_API_KEY=your_api_key
VITE_FIREBASE_AUTH_DOMAIN=your_project.firebaseapp.com
VITE_FIREBASE_PROJECT_ID=your_project_id
VITE_FIREBASE_STORAGE_BUCKET=your_project.appspot.com
VITE_FIREBASE_MESSAGING_SENDER_ID=your_sender_id
VITE_FIREBASE_APP_ID=your_app_id
```

### 4. Run locally
```bash
npm run dev
# Open http://localhost:5173
```

---

## Deploy to Netlify

### Option A — Drag & Drop (fastest)
```bash
npm run build
```
Then drag the `dist/` folder to [netlify.com/drop](https://netlify.com/drop)

### Option B — GitHub auto-deploy (recommended)
1. Push this project to a GitHub repo:
```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/YOUR_USERNAME/timber-bill.git
git push -u origin main
```
2. Go to [app.netlify.com](https://app.netlify.com) → **Add new site** → **Import from Git**
3. Select your repo
4. Build settings are auto-detected from `netlify.toml`
5. Go to **Site settings** → **Environment variables** → Add all your `VITE_*` keys
6. Click **Deploy site** ✅

---

## Features
- 🔐 Google Sign-In via Firebase Auth
- ☁️ Bills stored in Firestore (per user)
- 📐 Auto CFT calculator (Length × Width × Thickness)
- 🌳 8 wood types with rate memory per type
- ✏️ Edit items after adding
- 🖼️ Share bill as JPEG image (WhatsApp ready)
- 📊 Bill history with filters (date, amount, sort, search)
- 👤 Account profile with mill details
- 📱 Mobile-first dark UI

---

## Tech Stack
- **Frontend:** React 18 + Vite 5
- **Auth:** Firebase Authentication (Google)
- **Database:** Firebase Firestore
- **Hosting:** Netlify
- **Image:** html2canvas → JPEG
