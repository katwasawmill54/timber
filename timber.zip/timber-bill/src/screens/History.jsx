import { useState, useMemo } from 'react'
import { Logo } from '../components/Logo'
import { fmtINR, fmtDate, generateAndShareImage, toWords } from '../helpers'

const DATE_FILTERS = [
  { key:'all',   label:'All'       },
  { key:'today', label:'Today'     },
  { key:'week',  label:'This Week' },
  { key:'month', label:'This Month'},
  { key:'custom',label:'📅 Custom' },
]

export function History({ bills, onBack, onOpen, onDelete, onClearAll }) {
  const [search,      setSearch]      = useState('')
  const [dateFilter,  setDateFilter]  = useState('all')
  const [customFrom,  setCustomFrom]  = useState('')
  const [customTo,    setCustomTo]    = useState('')
  const [sortBy,      setSortBy]      = useState('newest')
  const [amountRange, setAmountRange] = useState('all')
  const [sharing,     setSharing]     = useState(null)

  const filtered = useMemo(() => {
    const now = new Date()
    let list = [...bills]

    // Text search
    if (search.trim()) {
      const q = search.toLowerCase()
      list = list.filter(b =>
        (b.buyer||'').toLowerCase().includes(q) ||
        (b.phone||'').includes(q)
      )
    }

    // Date
    if (dateFilter === 'today') {
      list = list.filter(b => b.date && new Date(b.date).toDateString() === now.toDateString())
    } else if (dateFilter === 'week') {
      const start = new Date(now); start.setDate(now.getDate() - now.getDay()); start.setHours(0,0,0,0)
      list = list.filter(b => b.date && new Date(b.date) >= start)
    } else if (dateFilter === 'month') {
      list = list.filter(b => {
        if (!b.date) return false
        const d = new Date(b.date)
        return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
      })
    } else if (dateFilter === 'custom' && customFrom && customTo) {
      const f = new Date(customFrom)
      const t = new Date(customTo); t.setHours(23,59,59,999)
      list = list.filter(b => b.date && new Date(b.date) >= f && new Date(b.date) <= t)
    }

    // Amount
    if (amountRange !== 'all') {
      list = list.filter(b => {
        const a = b.totAmt || 0
        if (amountRange === 'lt5k')    return a < 5000
        if (amountRange === '5k-20k')  return a >= 5000 && a < 20000
        if (amountRange === '20k-50k') return a >= 20000 && a < 50000
        if (amountRange === 'gt50k')   return a >= 50000
        return true
      })
    }

    // Sort
    list.sort((a, b) => {
      if (sortBy === 'newest')  return new Date(b.savedAt) - new Date(a.savedAt)
      if (sortBy === 'oldest')  return new Date(a.savedAt) - new Date(b.savedAt)
      if (sortBy === 'highest') return (b.totAmt||0) - (a.totAmt||0)
      if (sortBy === 'lowest')  return (a.totAmt||0) - (b.totAmt||0)
      return 0
    })

    return list
  }, [bills, search, dateFilter, customFrom, customTo, sortBy, amountRange])

  const shareOld = async (bill) => {
    setSharing(bill.id)
    try {
      await generateAndShareImage({
        buyer: bill.buyer, phone: bill.phone, address: bill.address, date: bill.date,
        items: bill.items, gstEnabled: bill.gstEnabled || false, toWords, fmtINR
      })
    } catch(e) {
      if (e.name !== 'AbortError') alert('Could not share.')
    } finally { setSharing(null) }
  }

  return (
    <div className="screen active">
      <div className="top-nav">
        <button className="nav-btn wood" onClick={onBack}>‹ Home</button>
        <div className="nav-center"><Logo size={26} /><span className="nav-title">Bill History</span></div>
        <button className="nav-btn red" onClick={onClearAll} style={{ fontSize: 12 }}>Clear All</button>
      </div>

      {/* FILTER PANEL */}
      <div className="filter-panel">
        <div className="search-bar">
          <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="var(--text3)" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="M21 21l-4.35-4.35"/></svg>
          <input className="search-input" value={search} onChange={e => setSearch(e.target.value)} placeholder="Search by buyer name or phone..." />
          {search && <button onClick={() => setSearch('')} style={{ background:'none',border:'none',color:'var(--text3)',fontSize:16,cursor:'pointer',padding:0 }}>✕</button>}
        </div>

        {/* Date chips */}
        <div className="chips-row">
          {DATE_FILTERS.map(f => (
            <button key={f.key} className={`fchip ${dateFilter === f.key ? 'active' : ''}`}
              onClick={() => setDateFilter(f.key)}>{f.label}</button>
          ))}
        </div>

        {/* Custom date */}
        {dateFilter === 'custom' && (
          <div className="date-range">
            <div>
              <div style={{ fontSize:10, color:'var(--text3)', fontWeight:700, textTransform:'uppercase', letterSpacing:'.05em', marginBottom:4 }}>From</div>
              <input type="date" className="date-input" value={customFrom} onChange={e => setCustomFrom(e.target.value)} />
            </div>
            <div>
              <div style={{ fontSize:10, color:'var(--text3)', fontWeight:700, textTransform:'uppercase', letterSpacing:'.05em', marginBottom:4 }}>To</div>
              <input type="date" className="date-input" value={customTo} onChange={e => setCustomTo(e.target.value)} />
            </div>
          </div>
        )}

        {/* Sort + Amount */}
        <div className="filter-selects">
          <select className="filter-select" value={sortBy} onChange={e => setSortBy(e.target.value)}>
            <option value="newest">Newest First</option>
            <option value="oldest">Oldest First</option>
            <option value="highest">Highest Amount</option>
            <option value="lowest">Lowest Amount</option>
          </select>
          <select className="filter-select" value={amountRange} onChange={e => setAmountRange(e.target.value)}>
            <option value="all">Any Amount</option>
            <option value="lt5k">Below ₹5,000</option>
            <option value="5k-20k">₹5K – ₹20K</option>
            <option value="20k-50k">₹20K – ₹50K</option>
            <option value="gt50k">Above ₹50K</option>
          </select>
        </div>

        <div className="filter-count">{filtered.length} bill{filtered.length !== 1 ? 's' : ''} found</div>
      </div>

      {/* LIST */}
      <div className="scroll-body" style={{ padding: '12px 14px' }}>
        {filtered.length === 0
          ? <div className="empty-state">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" opacity=".3"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>
              <p>{bills.length === 0 ? 'No Bills Saved' : 'No Bills Found'}</p>
              <small>{bills.length === 0 ? 'Save a bill to see it here' : 'Try adjusting your filters'}</small>
            </div>
          : filtered.map(b => (
            <div key={b.id} className="hist-card">
              <div className="hist-top">
                <div>
                  <div className="hist-buyer">{b.buyer || 'Unknown Buyer'}</div>
                  <div className="hist-date">{fmtDate(b.date)}</div>
                </div>
                <div className="hist-amount">{fmtINR(b.totAmt)}</div>
              </div>
              <div className="hist-meta">
                <span className="hist-chip">📦 {b.items?.length || 0} items</span>
                <span className="hist-chip">📐 {(b.totCFT||0).toFixed(2)} CFT</span>
                {b.phone && <span className="hist-chip">📞 {b.phone}</span>}
                {b.gstEnabled && <span className="hist-chip">GST 18%</span>}
              </div>
              <div className="hist-actions">
                <button className="hist-btn hist-share" onClick={() => shareOld(b)} disabled={sharing === b.id}>
                  {sharing === b.id ? '⏳' : '🖼️ Share'}
                </button>
                <button className="hist-btn hist-open" onClick={() => onOpen(b)}>Open</button>
                <button className="hist-btn hist-del" onClick={() => onDelete(b.id)}>🗑</button>
              </div>
            </div>
          ))
        }
        <div style={{ height: 20 }} />
      </div>
    </div>
  )
}
