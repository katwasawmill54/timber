import { Logo } from '../components/Logo'
import { fmtINR } from '../helpers'

export function Home({ user, profile, bills, onBill, onHistory, onAccount, onSignOut }) {
  const name = profile?.name || user?.displayName || user?.email?.split('@')[0] || 'User'

  const now = new Date()
  const monthBills = bills.filter(b => {
    const d = new Date(b.savedAt)
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
  })

  const recent = bills.slice(0, 3)

  return (
    <div className="screen active">
      <div className="top-nav">
        <div style={{ width: 60 }} />
        <div className="nav-center">
          <Logo size={28} />
          <span className="nav-title">TIMBER BILL</span>
        </div>
        <button className="nav-btn red" onClick={onSignOut}>Sign Out</button>
      </div>

      <div className="scroll-body" style={{ padding: '16px 14px' }}>

        {/* Banner */}
        <div className="home-banner">
          <div className="home-banner-ring1" />
          <div className="home-banner-ring2" />
          <div className="home-banner-tag">Welcome back</div>
          <div className="home-banner-name">{name}</div>
          <div className="home-banner-hint">What would you like to do today?</div>
        </div>

        {/* Stats */}
        <div className="home-stats">
          <div className="home-stat">
            <div className="home-stat-label">Total Bills</div>
            <div className="home-stat-value" style={{ color: 'var(--wood)' }}>{bills.length}</div>
          </div>
          <div className="home-stat">
            <div className="home-stat-label">This Month</div>
            <div className="home-stat-value" style={{ color: 'var(--green)' }}>{monthBills.length}</div>
          </div>
        </div>

        {/* Menu */}
        <div className="sec-label">Quick Actions</div>

        <div className="home-card" onClick={onBill}>
          <div className="home-card-icon" style={{ background: 'linear-gradient(135deg,#1a2a40,#0a84ff)' }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#0a84ff" strokeWidth="2">
              <rect x="4" y="2" width="16" height="20" rx="2"/>
              <path d="M8 10h8M8 14h5M8 6h8"/>
            </svg>
          </div>
          <div className="home-card-body">
            <div className="home-card-title">Cut Size Bill</div>
            <div className="home-card-sub">Calculate CFT, rate &amp; generate bill</div>
          </div>
          <div className="home-card-arrow">›</div>
        </div>

        <div className="home-card" onClick={onHistory}>
          <div className="home-card-icon" style={{ background: 'linear-gradient(135deg,#2a1a0a,#C9813A)' }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#C9813A" strokeWidth="2">
              <circle cx="12" cy="12" r="10"/>
              <polyline points="12 6 12 12 16 14"/>
            </svg>
          </div>
          <div className="home-card-body">
            <div className="home-card-title">Bill History</div>
            <div className="home-card-sub">View and share your past bills</div>
          </div>
          <div className="home-card-arrow">›</div>
        </div>

        <div className="home-card" onClick={onAccount}>
          <div className="home-card-icon" style={{ background: 'linear-gradient(135deg,#1a1a2e,#6a4fff)' }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" strokeWidth="2">
              <circle cx="12" cy="8" r="4"/>
              <path d="M4 20c0-4 3.6-7 8-7s8 3 8 7"/>
            </svg>
          </div>
          <div className="home-card-body">
            <div className="home-card-title">Account Details</div>
            <div className="home-card-sub">View and edit your profile</div>
          </div>
          <div className="home-card-arrow">›</div>
        </div>

        {/* Recent Bills */}
        <div className="sec-label" style={{ marginTop: 10 }}>Recent Bills</div>
        {recent.length === 0
          ? <div style={{ textAlign: 'center', color: 'var(--text3)', fontSize: 13, padding: '20px 0' }}>No bills saved yet</div>
          : recent.map(b => (
            <div key={b.id} className="hist-card">
              <div className="hist-top">
                <div>
                  <div className="hist-buyer">{b.buyer || 'Unknown'}</div>
                  <div className="hist-date">{b.date ? new Date(b.date).toLocaleDateString('en-IN',{day:'2-digit',month:'short',year:'numeric'}) : '—'} · {b.items?.length || 0} items</div>
                </div>
                <div className="hist-amount">{fmtINR(b.totAmt)}</div>
              </div>
              <div className="hist-actions">
                <button className="hist-btn hist-open" onClick={() => onBill(b)}>Open</button>
              </div>
            </div>
          ))
        }

        <div style={{ height: 20 }} />
      </div>
    </div>
  )
}
