import { Logo } from '../components/Logo'

export function Welcome({ onStart }) {
  return (
    <div className="screen active" style={{ overflowY: 'auto' }}>
      <div className="welcome-screen">
        <div className="welcome-logo-wrap"><Logo size={80} /></div>
        <div className="welcome-title">TIMBER BILL</div>
        <div className="welcome-sub">Professional billing for sawmill owners</div>

        <div className="welcome-features">
          <div className="feature-row">
            <div className="feature-icon">📐</div>
            <div className="feature-text">
              <strong>Auto CFT Calculator</strong>
              Enter dimensions — CFT and cost calculated instantly
            </div>
          </div>
          <div className="feature-row">
            <div className="feature-icon">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8">
                <rect x="2" y="8" width="8" height="10" rx="1"/>
                <rect x="14" y="11" width="8" height="7" rx="1"/>
                <path d="M10 10h4M10 14h4"/>
                <circle cx="6" cy="20" r="1.5" fill="currentColor"/>
                <circle cx="18" cy="20" r="1.5" fill="currentColor"/>
                <path d="M2 8V6a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v2"/>
                <path d="M10 6V4"/>
              </svg>
            </div>
            <div className="feature-text">
              <strong>Built for Sawmill Owners</strong>
              Teak, Honni, Neem & more — rates remembered per wood type
            </div>
          </div>
          <div className="feature-row">
            <div className="feature-icon">☁️</div>
            <div className="feature-text">
              <strong>Cloud Saved</strong>
              Your bills saved securely, access from any device
            </div>
          </div>
          <div className="feature-row">
            <div className="feature-icon">🖼️</div>
            <div className="feature-text">
              <strong>Share as Image</strong>
              Bill image shared via WhatsApp in one tap
            </div>
          </div>
        </div>

        <button className="welcome-cta" onClick={onStart}>Get Started →</button>
        <div className="welcome-version">TIMBER BILL v2.0 · Made for Timber Industry</div>
      </div>
    </div>
  )
}
