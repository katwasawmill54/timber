import { useState, useRef } from 'react'
import { Logo } from '../components/Logo'
import { WoodPicker } from '../components/WoodPicker'
import { toWords, fmtINR, generateAndShareImage } from '../helpers'

const EMPTY_DIMS = { L: '', W: '', T: '', N: '', R: '' }

export function Bill({ onBack, onSave, initialBill }) {
  /* ── state ── */
  const [buyer,   setBuyer]   = useState(initialBill?.buyer   || '')
  const [phone,   setPhone]   = useState(initialBill?.phone   || '')
  const [address, setAddress] = useState(initialBill?.address || '')
  const [date,    setDate]    = useState(initialBill?.date    || new Date().toISOString().split('T')[0])
  const [items,   setItems]   = useState(initialBill?.items   ? JSON.parse(JSON.stringify(initialBill.items)) : [])
  const [dims,    setDims]    = useState(EMPTY_DIMS)
  const [selWood, setSelWood] = useState('')
  const [woodOpen,setWoodOpen]= useState(false)
  const [woodRates, setWoodRates] = useState({})
  const [gst,     setGst]     = useState(false)
  const [sharing, setSharing] = useState(false)
  const [idc,     setIdc]     = useState(1)
  /* edit */
  const [editId,      setEditId]      = useState(null)
  const [editDims,    setEditDims]    = useState(EMPTY_DIMS)
  const [editWood,    setEditWood]    = useState('')
  const [editWoodOpen,setEditWoodOpen]= useState(false)

  const totAmt = items.reduce((s, i) => s + i.amount, 0)
  const totCFT = items.reduce((s, i) => s + i.cft,    0)
  const gstAmt = gst ? totAmt * 0.18 : 0
  const grand  = totAmt + gstAmt

  /* ── calc ── */
  const calcCFT = (d) => {
    const L = parseFloat(d.L)||0, W = parseFloat(d.W)||0
    const T = parseFloat(d.T)||0, N = parseFloat(d.N)||1
    return (L && W && T) ? L*(W/12)*(T/12)*N : 0
  }

  /* ── pick wood ── */
  const pickWood = (w) => {
    setSelWood(w)
    setWoodOpen(false)
    if (woodRates[w] !== undefined)
      setDims(d => ({ ...d, R: String(woodRates[w]) }))
  }

  /* ── add item ── */
  const addItem = () => {
    const L = parseFloat(dims.L), W = parseFloat(dims.W)
    const T = parseFloat(dims.T), N = parseFloat(dims.N)||1
    const R = parseFloat(dims.R)
    if (!L||!W||!T||!R) { alert('Please fill Length, Width, Thickness and Rate.'); return }
    const cft = L*(W/12)*(T/12)*N
    const wood = selWood || 'General'
    setWoodRates(r => ({ ...r, [wood]: R }))
    setItems(prev => [...prev, { id: idc, wood, L, W, T, N, cft, rate: R, amount: cft*R }])
    setIdc(c => c+1)
    setDims(d => ({ ...d, L: '', N: '' })) // keep W, T, R
  }

  /* ── remove ── */
  const removeItem = (id) => setItems(prev => prev.filter(i => i.id !== id))

  /* ── open edit ── */
  const openEdit = (item) => {
    setEditId(item.id)
    setEditWood(item.wood)
    setEditDims({ L: String(item.L), W: String(item.W), T: String(item.T), N: String(item.N), R: String(item.rate) })
  }

  /* ── save edit ── */
  const saveEdit = () => {
    const L = parseFloat(editDims.L), W = parseFloat(editDims.W)
    const T = parseFloat(editDims.T), N = parseFloat(editDims.N)||1
    const R = parseFloat(editDims.R)
    if (!L||!W||!T||!R) { alert('Please fill all fields.'); return }
    const cft = L*(W/12)*(T/12)*N
    setItems(prev => prev.map(i => i.id === editId
      ? { ...i, wood: editWood, L, W, T, N, cft, rate: R, amount: cft*R }
      : i))
    setWoodRates(r => ({ ...r, [editWood]: R }))
    setEditId(null)
  }

  /* ── share ── */
  const share = async () => {
    if (items.length === 0) { alert('Add at least one item.'); return }
    setSharing(true)
    try {
      const { totAmt: amt, totCFT: cft } = await generateAndShareImage({
        buyer, phone, address, date, items, gstEnabled: gst, toWords, fmtINR
      })
      // Auto-save to history
      onSave({ buyer, phone, address, date, items, gstEnabled: gst, totAmt: amt, totCFT: cft })
    } catch (e) {
      if (e.name !== 'AbortError') alert('Could not share. Image downloaded instead.')
    } finally { setSharing(false) }
  }

  /* ── clear ── */
  const clear = () => {
    if (items.length > 0 && !confirm('Clear all items?')) return
    setItems([]); setDims(EMPTY_DIMS); setSelWood('')
    setBuyer(''); setPhone(''); setAddress('')
    setDate(new Date().toISOString().split('T')[0])
    setGst(false)
  }

  const liveCFT  = calcCFT(dims)
  const liveAmt  = liveCFT * (parseFloat(dims.R)||0)
  const editCFT  = calcCFT(editDims)
  const editCost = editCFT * (parseFloat(editDims.R)||0)

  return (
    <div className="screen active">

      {/* NAV */}
      <div className="top-nav">
        <button className="nav-btn wood" onClick={onBack}>‹ Home</button>
        <div className="nav-center"><Logo size={26} /><span className="nav-title">New Bill</span></div>
        <button className="nav-btn green" onClick={share} disabled={sharing}>
          {sharing ? '⏳' : 'Share'}
        </button>
      </div>

      {/* SCROLL */}
      <div className="scroll-body">

        {/* Buyer */}
        <div className="sec-label">Party Details</div>
        <div className="field-group">
          {[
            { label:'Name',    id:'buyer',   val:buyer,   set:setBuyer,   ph:'Buyer name',    type:'text' },
            { label:'Phone',   id:'phone',   val:phone,   set:setPhone,   ph:'Mobile number', type:'tel'  },
            { label:'Address', id:'address', val:address, set:setAddress, ph:'Address',       type:'text' },
          ].map(({ label, id, val, set, ph, type }) => (
            <div key={id} className="field-row">
              <span className="field-label">{label}</span>
              <input className="field-input" type={type} value={val} onChange={e => set(e.target.value)} placeholder={ph} />
            </div>
          ))}
          <div className="field-row">
            <span className="field-label">Date</span>
            <input className="field-input" type="date" value={date} onChange={e => setDate(e.target.value)} />
          </div>
        </div>

        {/* Stats */}
        <div className="stats-bar">
          <div className="stat-box"><div className="stat-lbl">Total CFT</div><div className="stat-val">{totCFT.toFixed(3)}</div></div>
          <div className="stat-box"><div className="stat-lbl">Total Amount</div><div className="stat-val">{totAmt.toLocaleString('en-IN',{maximumFractionDigits:0})}</div></div>
        </div>

        {/* Items */}
        <div className="sec-label">Cut Items</div>
        {items.length === 0
          ? <div className="empty-state">
              <svg width="48" height="48" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.2" opacity=".3"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>
              <p>No Items Added</p>
              <small>Add your first size calculation below</small>
            </div>
          : items.map((it, i) => (
            <div key={it.id} className="item-card">
              <button className="item-del" onClick={() => removeItem(it.id)}>✕</button>
              <button className="item-edit" onClick={() => openEdit(it)}>✎</button>
              <div className="item-top">
                <div className="item-name">{i+1}. {it.wood}</div>
                <div className="item-amount">{fmtINR(it.amount)}</div>
              </div>
              <div className="chips">
                <div className="chip"><span>Size</span><strong>{it.L}ft × {it.W}" × {it.T}"</strong></div>
                <div className="chip"><span>Nos</span><strong>{it.N}</strong></div>
                <div className="chip"><span>CFT</span><strong>{it.cft.toFixed(3)}</strong></div>
                <div className="chip"><span>Rate</span><strong>Rs.{it.rate.toLocaleString('en-IN')}</strong></div>
              </div>
            </div>
          ))
        }

        {/* Total */}
        {items.length > 0 && (
          <>
            <div className="total-card">
              <div className="total-row">
                <span className="total-label">Grand Total{gst ? ' (incl. GST)' : ''}</span>
                <span className="total-amount">{fmtINR(grand)}</span>
              </div>
              <div className="total-words">{toWords(Math.round(grand))} Rupees Only</div>
            </div>

            {/* GST Toggle */}
            <div className="gst-row" onClick={() => setGst(g => !g)}>
              <div>
                <div className="gst-label-main">Include GST (18%)</div>
                <div className="gst-label-sub">{gst ? `With GST: +${fmtINR(gstAmt)}` : 'Without GST'}</div>
              </div>
              <div className="toggle-track" style={{ background: gst ? 'var(--green)' : 'var(--bg3)' }}>
                <div className="toggle-thumb" style={{ left: gst ? 21 : 3, background: gst ? '#fff' : '#636366' }} />
              </div>
            </div>
          </>
        )}

        <div style={{ height: 12 }} />
      </div>

      {/* ADD PANEL */}
      <div className="add-panel">
        <button className="wood-btn" onClick={() => setWoodOpen(true)}>
          <div style={{ display:'flex', alignItems:'center', gap:9 }}>
            <Logo size={17} />
            <span className={selWood ? '' : 'placeholder'}>{selWood || 'Select Wood Type'}</span>
          </div>
          <span style={{ color:'var(--text3)', fontSize:18 }}>›</span>
        </button>

        <div className="dim-grid">
          {[
            { key:'L', lbl:'Length', unit:'ft',    step:0.5  },
            { key:'W', lbl:'Width',  unit:'in',    step:0.25 },
            { key:'T', lbl:'Thick',  unit:'in',    step:0.25 },
            { key:'N', lbl:'Nos',    unit:'nos',   step:1    },
            { key:'R', lbl:'Rate',   unit:'₹/cft', step:1    },
          ].map(({ key, lbl, unit, step }) => (
            <div key={key} className="dim-box">
              <span className="dim-lbl">{lbl}</span>
              <input className="dim-inp" type="number" value={dims[key]} step={step} min={0} placeholder="0"
                onChange={e => setDims(d => ({ ...d, [key]: e.target.value }))} />
              <span className="dim-unit">{unit}</span>
            </div>
          ))}
        </div>

        <div className="calc-row">
          <div className="calc-cft">CFT: <strong>{liveCFT.toFixed(3)}</strong></div>
          <div className="calc-cost">Total: {fmtINR(liveAmt)}</div>
        </div>

        <div className="add-btns">
          <button className="add-btn" onClick={addItem}>+ Add</button>
          <button className="clear-btn" onClick={clear}>Clear</button>
        </div>
      </div>

      {/* WOOD PICKER */}
      <WoodPicker open={woodOpen} selected={selWood} onSelect={pickWood} onClose={() => setWoodOpen(false)} />

      {/* EDIT MODAL */}
      {editId !== null && (
        <div className="edit-overlay open" onClick={e => { if(e.target===e.currentTarget) setEditId(null) }}>
          <div className="edit-sheet">
            <div className="edit-handle" />
            <div className="edit-title">Edit Item</div>
            <button className="edit-wood-btn" onClick={() => setEditWoodOpen(true)}>
              <span>{editWood || 'Select Wood Type'}</span>
              <span style={{ color:'var(--text3)', fontSize:18 }}>›</span>
            </button>
            <div className="dim-grid">
              {[
                { key:'L', lbl:'Length', unit:'ft',    step:0.5  },
                { key:'W', lbl:'Width',  unit:'in',    step:0.25 },
                { key:'T', lbl:'Thick',  unit:'in',    step:0.25 },
                { key:'N', lbl:'Nos',    unit:'nos',   step:1    },
                { key:'R', lbl:'Rate',   unit:'₹/cft', step:1    },
              ].map(({ key, lbl, unit, step }) => (
                <div key={key} className="dim-box">
                  <span className="dim-lbl">{lbl}</span>
                  <input className="dim-inp" type="number" value={editDims[key]} step={step} min={0} placeholder="0"
                    onChange={e => setEditDims(d => ({ ...d, [key]: e.target.value }))} />
                  <span className="dim-unit">{unit}</span>
                </div>
              ))}
            </div>
            <div className="calc-row">
              <div className="calc-cft">CFT: <strong>{editCFT.toFixed(3)}</strong></div>
              <div className="calc-cost">Total: {fmtINR(editCost)}</div>
            </div>
            <button className="edit-save-btn" onClick={saveEdit}>✓ Save Changes</button>
          </div>
        </div>
      )}

      <WoodPicker open={editWoodOpen} selected={editWood} onSelect={w => { setEditWood(w); setEditWoodOpen(false) }} onClose={() => setEditWoodOpen(false)} />
    </div>
  )
}
