import { useState } from 'react'
import { Logo } from '../components/Logo'

export function Login({ onBack, signInWithGoogle }) {
  const [loading, setLoading] = useState(false)
  const [error,   setError]   = useState('')

  const handleGoogle = async () => {
    setError(''); setLoading(true)
    try {
      await signInWithGoogle()
      // App.jsx auth listener handles navigation
    } catch (e) {
      setError(e.code === 'auth/popup-closed-by-user'
        ? 'Sign-in was cancelled.'
        : 'Google sign-in failed. Please try again.')
    } finally { setLoading(false) }
  }

  return (
    <div className="screen active" style={{ overflowY: 'auto' }}>
      <div className="login-header">
        <button className="nav-btn wood" onClick={onBack} style={{ padding: '7px 12px' }}>‹ Back</button>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
          <Logo size={26} />
          <span className="nav-title">TIMBER BILL</span>
        </div>
        <div style={{ width: 60 }} />
      </div>

      <div className="login-body">
        <div style={{ textAlign: 'center', marginBottom: 32, marginTop: 16 }}>
          <div style={{ fontSize: 40, marginBottom: 12 }}>🪵</div>
          <div style={{ fontSize: 22, fontWeight: 700, color: 'var(--text)', marginBottom: 6 }}>Welcome Back</div>
          <div style={{ fontSize: 14, color: 'var(--text3)' }}>Sign in to access your bills and estimates</div>
        </div>

        {error && (
          <div className="login-msg error" style={{ display: 'block', marginBottom: 16 }}>{error}</div>
        )}

        {/* Google Sign In */}
        <button className="google-btn" onClick={handleGoogle} disabled={loading}>
          {loading ? '⏳ Signing in...' : (
            <>
              <svg className="google-icon" viewBox="0 0 24 24">
                <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z"/>
                <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
              </svg>
              Continue with Google
            </>
          )}
        </button>

        <div style={{ textAlign: 'center', marginTop: 8 }}>
          <div style={{ fontSize: 13, color: 'var(--text3)', lineHeight: 1.6 }}>
            By signing in, you agree to our Terms of Service.<br/>
            Your bills are stored securely in Firebase.
          </div>
        </div>
      </div>
    </div>
  )
}
