import { useState, useEffect } from 'react'
import { Logo } from '../components/Logo'

export function Account({ user, profile, bills, onBack, onSaveProfile, onClearAll, onSignOut }) {
  const [name,    setName]    = useState(profile?.name    || '')
  const [mill,    setMill]    = useState(profile?.mill    || '')
  const [phone,   setPhone]   = useState(profile?.phone   || '')
  const [address, setAddress] = useState(profile?.address || '')
  const [gst,     setGst]     = useState(profile?.gst     || '')
  const [saved,   setSaved]   = useState(false)

  useEffect(() => {
    setName(profile?.name    || '')
    setMill(profile?.mill    || '')
    setPhone(profile?.phone  || '')
    setAddress(profile?.address || '')
    setGst(profile?.gst     || '')
  }, [profile])

  const displayName  = profile?.name || user?.displayName || user?.email?.split('@')[0] || '—'
  const displayEmail = user?.email || '—'

  const now = new Date()
  const monthCount = bills.filter(b => {
    const d = new Date(b.savedAt)
    return d.getMonth() === now.getMonth() && d.getFullYear() === now.getFullYear()
  }).length

  const save = async () => {
    await onSaveProfile({ name, mill, phone, address, gst })
    setSaved(true)
    setTimeout(() => setSaved(false), 2000)
  }

  return (
    <div className="screen active">
      <div className="top-nav">
        <button className="nav-btn wood" onClick={onBack}>‹ Home</button>
        <div className="nav-center"><Logo size={26} /><span className="nav-title">Account</span></div>
        <div style={{ width: 60 }} />
      </div>

      <div className="scroll-body" style={{ padding: '16px 14px' }}>

        {/* Avatar */}
        <div className="acct-avatar-wrap">
          <div className="acct-avatar">🪵</div>
          <div className="acct-name">{displayName}</div>
          <div className="acct-email">{displayEmail}</div>
        </div>

        {/* Profile form */}
        <div className="sec-label">Profile</div>
        <div className="field-group" style={{ marginBottom: 14 }}>
          {[
            { label:'Name',      val:name,    set:setName,    ph:'Your name'        },
            { label:'Mill Name', val:mill,    set:setMill,    ph:'e.g. Katwa Saw Mill' },
            { label:'Phone',     val:phone,   set:setPhone,   ph:'Mobile number'    },
            { label:'Address',   val:address, set:setAddress, ph:'Mill address'     },
            { label:'GST No.',   val:gst,     set:setGst,     ph:'GST number (opt)' },
          ].map(({ label, val, set, ph }) => (
            <div key={label} className="field-row">
              <span className="field-label">{label}</span>
              <input className="field-input" value={val} onChange={e => set(e.target.value)} placeholder={ph} />
            </div>
          ))}
        </div>

        <button className="save-btn" onClick={save}>
          {saved ? '✅ Saved!' : '💾 Save Profile'}
        </button>

        {/* Stats */}
        <div className="sec-label" style={{ marginTop: 8 }}>Account Stats</div>
        <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap:10, marginBottom:20 }}>
          <div style={{ background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:'var(--r)',padding:14,textAlign:'center' }}>
            <div style={{ fontSize:10,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:6 }}>Total Bills</div>
            <div style={{ fontSize:28,fontWeight:800,color:'var(--wood)' }}>{bills.length}</div>
          </div>
          <div style={{ background:'var(--bg2)',border:'1px solid var(--border)',borderRadius:'var(--r)',padding:14,textAlign:'center' }}>
            <div style={{ fontSize:10,color:'var(--text3)',textTransform:'uppercase',letterSpacing:'.05em',marginBottom:6 }}>This Month</div>
            <div style={{ fontSize:28,fontWeight:800,color:'var(--green)' }}>{monthCount}</div>
          </div>
        </div>

        {/* Danger zone */}
        <div className="sec-label">Account</div>
        <div className="danger-card">
          <div className="danger-row">
            <div>
              <div style={{ fontSize:14,fontWeight:600,color:'var(--text)' }}>App Version</div>
              <div style={{ fontSize:12,color:'var(--text3)' }}>TIMBER BILL v2.0</div>
            </div>
            <div style={{ fontSize:12,color:'var(--text3)' }}>Firebase</div>
          </div>
          <div className="danger-row">
            <button className="danger-btn" onClick={onClearAll}>🗑 Clear All Bill History</button>
          </div>
          <div className="danger-row">
            <button className="danger-btn" onClick={onSignOut}>⎋ Sign Out</button>
          </div>
        </div>

      </div>
    </div>
  )
}
