import { useState, useEffect, useCallback } from 'react'
import {
  collection, doc, addDoc, getDocs, deleteDoc,
  query, orderBy, setDoc, getDoc
} from 'firebase/firestore'
import { db } from '../firebase'

export function useBills(user) {
  const [bills, setBills]     = useState([])
  const [profile, setProfile] = useState({})
  const [loading, setLoading] = useState(false)

  const billsRef = useCallback(() =>
    collection(db, 'users', user.uid, 'bills'), [user])

  const profileRef = useCallback(() =>
    doc(db, 'users', user.uid, 'profile', 'data'), [user])

  /* ── Load bills ── */
  const loadBills = useCallback(async () => {
    if (!user) return
    setLoading(true)
    try {
      const q = query(billsRef(), orderBy('savedAt', 'desc'))
      const snap = await getDocs(q)
      setBills(snap.docs.map(d => ({ id: d.id, ...d.data() })))
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }, [user, billsRef])

  /* ── Load profile ── */
  const loadProfile = useCallback(async () => {
    if (!user) return
    try {
      const snap = await getDoc(profileRef())
      if (snap.exists()) setProfile(snap.data())
    } catch (e) { console.error(e) }
  }, [user, profileRef])

  useEffect(() => {
    if (user) { loadBills(); loadProfile() }
    else { setBills([]); setProfile({}) }
  }, [user, loadBills, loadProfile])

  /* ── Save bill ── */
  const saveBill = async (billData) => {
    if (!user) return
    try {
      const ref = await addDoc(billsRef(), {
        ...billData,
        savedAt: new Date().toISOString()
      })
      setBills(prev => [{ id: ref.id, ...billData, savedAt: new Date().toISOString() }, ...prev])
    } catch (e) { console.error(e) }
  }

  /* ── Delete bill ── */
  const deleteBill = async (id) => {
    if (!user) return
    try {
      await deleteDoc(doc(db, 'users', user.uid, 'bills', id))
      setBills(prev => prev.filter(b => b.id !== id))
    } catch (e) { console.error(e) }
  }

  /* ── Save profile ── */
  const saveProfile = async (data) => {
    if (!user) return
    try {
      await setDoc(profileRef(), data)
      setProfile(data)
    } catch (e) { console.error(e) }
  }

  return { bills, profile, loading, saveBill, deleteBill, saveProfile, loadBills, loadProfile }
}
