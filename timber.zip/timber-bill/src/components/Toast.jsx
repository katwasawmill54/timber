import { useState, useCallback } from 'react'

let _show = null
export function useToast() {
  const [msg, setMsg] = useState('')
  const [visible, setVisible] = useState(false)

  const showToast = useCallback((m) => {
    setMsg(m); setVisible(true)
    setTimeout(() => setVisible(false), 2200)
  }, [])

  return { msg, visible, showToast }
}

export function Toast({ msg, visible }) {
  return <div className={`toast ${visible ? 'show' : ''}`}>{msg}</div>
}
