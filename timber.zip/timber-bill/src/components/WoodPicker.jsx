import { WOODS } from '../helpers'

export function WoodPicker({ open, selected, onSelect, onClose }) {
  return (
    <div className={`modal-overlay ${open ? 'open' : ''}`} onClick={e => { if (e.target === e.currentTarget) onClose() }}>
      <div className="modal-sheet">
        <div className="modal-handle" />
        <div className="modal-title-bar">Select Wood Type</div>
        {WOODS.map(w => (
          <div key={w} className={`modal-item ${selected === w ? 'selected' : ''}`} onClick={() => { onSelect(w); onClose() }}>
            <span>{w}</span>
            <span className="check">✓</span>
          </div>
        ))}
      </div>
    </div>
  )
}
