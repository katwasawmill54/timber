export function Logo({ size = 28 }) {
  return (
    <svg width={size} height={size} viewBox="0 0 100 100">
      <path d="M50,3 C53,2 57,1 60,3 C63,5 65,3 68,5 C71,7 73,5 76,8 C79,11 78,13 81,16 C84,19 86,18 88,22 C90,26 88,28 90,32 C92,36 94,37 94,41 C94,45 92,47 93,51 C94,55 96,57 95,61 C94,65 91,66 90,70 C89,74 91,77 88,80 C85,83 83,82 80,85 C77,88 78,91 74,93 C70,95 68,93 64,94 C60,95 59,97 55,97 C51,97 49,95 45,95 C41,95 39,97 35,96 C31,95 30,92 26,91 C22,90 20,92 17,89 C14,86 15,83 12,80 C9,77 7,78 5,74 C3,70 5,67 4,63 C3,59 1,57 1,53 C1,49 3,47 3,43 C3,39 1,37 2,33 C3,29 6,28 8,24 C10,20 9,18 12,15 C15,12 17,13 21,10 C25,7 24,5 28,3 C32,1 34,3 38,2 C42,1 45,4 50,3Z" fill="#C9813A"/>
      <circle cx="50" cy="50" r="40" fill="none" stroke="#111" strokeWidth="2.2"/>
      <circle cx="50" cy="50" r="33" fill="none" stroke="#111" strokeWidth="1.7"/>
      <circle cx="50" cy="50" r="26" fill="none" stroke="#111" strokeWidth="1.4"/>
      <circle cx="50" cy="50" r="19" fill="none" stroke="#111" strokeWidth="1.2"/>
      <circle cx="50" cy="50" r="12" fill="none" stroke="#111" strokeWidth="1.0"/>
      <circle cx="50" cy="50" r="6"  fill="none" stroke="#111" strokeWidth="0.8"/>
      <path d="M25,23 L31,33 L27,37" fill="none" stroke="#8B5010" strokeWidth="2" strokeLinecap="round"/>
      <path d="M75,77 L69,67 L73,63" fill="none" stroke="#8B5010" strokeWidth="2" strokeLinecap="round"/>
    </svg>
  )
}
