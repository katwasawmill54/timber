import { useState } from 'react'
import { useAuth }  from './hooks/useAuth'
import { useBills } from './hooks/useBills'
import { Toast, useToast } from './components/Toast'
import { Welcome } from './screens/Welcome'
import { Login }   from './screens/Login'
import { Home }    from './screens/Home'
import { Bill }    from './screens/Bill'
import { History } from './screens/History'
import { Account } from './screens/Account'

export default function App() {
  const { user, loading, signInWithGoogle, signOut } = useAuth()
  const { bills, profile, saveBill, deleteBill, saveProfile, loadBills } = useBills(user)
  const { msg, visible, showToast } = useToast()

  // 'welcome' | 'login' | 'home' | 'bill' | 'history' | 'account'
  const [screen, setScreen] = useState('welcome')
  const [billToEdit, setBillToEdit] = useState(null)

  // Redirect to home once logged in
  if (!loading && user && (screen === 'welcome' || screen === 'login')) {
    setScreen('home')
  }
  // Redirect to welcome if logged out
  if (!loading && !user && !['welcome', 'login'].includes(screen)) {
    setScreen('welcome')
  }

  /* ── handlers ── */
  const handleSignOut = async () => {
    if (!confirm('Sign out?')) return
    await signOut()
    setScreen('welcome')
  }

  const handleSaveBill = async (billData) => {
    await saveBill(billData)
    showToast('✅ Bill saved to history!')
  }

  const handleDeleteBill = async (id) => {
    if (!confirm('Delete this bill?')) return
    await deleteBill(id)
    showToast('Bill deleted')
  }

  const handleClearAll = async () => {
    if (!confirm('Delete ALL saved bills? This cannot be undone.')) return
    const all = [...bills]
    for (const b of all) await deleteBill(b.id)
    showToast('All bills cleared')
  }

  const openBill = (bill = null) => {
    setBillToEdit(bill)
    setScreen('bill')
  }

  /* ── Loading splash ── */
  if (loading) {
    return (
      <div className="app" style={{ display:'flex', alignItems:'center', justifyContent:'center' }}>
        <div style={{ color:'var(--wood)', fontSize:32 }}>🪵</div>
      </div>
    )
  }

  return (
    <div className="app">

      {screen === 'welcome' && (
        <Welcome onStart={() => setScreen('login')} />
      )}

      {screen === 'login' && (
        <Login
          onBack={() => setScreen('welcome')}
          signInWithGoogle={signInWithGoogle}
        />
      )}

      {screen === 'home' && user && (
        <Home
          user={user}
          profile={profile}
          bills={bills}
          onBill={openBill}
          onHistory={() => setScreen('history')}
          onAccount={() => setScreen('account')}
          onSignOut={handleSignOut}
        />
      )}

      {screen === 'bill' && user && (
        <Bill
          onBack={() => setScreen('home')}
          onSave={handleSaveBill}
          initialBill={billToEdit}
        />
      )}

      {screen === 'history' && user && (
        <History
          bills={bills}
          onBack={() => setScreen('home')}
          onOpen={(bill) => openBill(bill)}
          onDelete={handleDeleteBill}
          onClearAll={handleClearAll}
        />
      )}

      {screen === 'account' && user && (
        <Account
          user={user}
          profile={profile}
          bills={bills}
          onBack={() => setScreen('home')}
          onSaveProfile={saveProfile}
          onClearAll={handleClearAll}
          onSignOut={handleSignOut}
        />
      )}

      <Toast msg={msg} visible={visible} />
    </div>
  )
}
