import { initializeApp } from 'firebase/app';
import { getAuth, GoogleAuthProvider } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBqgI1-FrmZpquQ3KyXpCKGAiB5tgpmsy4",
  authDomain: "timber-bill-fd1ea.firebaseapp.com",
  projectId: "timber-bill-fd1ea",
  storageBucket: "timber-bill-fd1ea.firebasestorage.app",
  messagingSenderId: "679162722391",
  appId: "1:679162722391:web:8e0ed85016b9e6c1fb8b12",
  measurementId: "G-SNH4VFQ4RZ"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db   = getFirestore(app);
export const googleProvider = new GoogleAuthProvider();
