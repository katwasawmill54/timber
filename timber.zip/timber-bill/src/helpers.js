export const WOODS = [
  'Teak (R)', 'Teak (A)', 'Honni',
  'Akeshiya (Mysore Teak)', 'Neem', 'Jali', 'Matthi', 'Others'
]

export function toWords(n) {
  if (!n || n === 0) return 'Zero'
  const a = ['','One','Two','Three','Four','Five','Six','Seven','Eight','Nine','Ten',
    'Eleven','Twelve','Thirteen','Fourteen','Fifteen','Sixteen','Seventeen','Eighteen','Nineteen']
  const b = ['','','Twenty','Thirty','Forty','Fifty','Sixty','Seventy','Eighty','Ninety']
  function hw(x) {
    if (x < 20) return a[x]
    if (x < 100) return b[Math.floor(x/10)] + (x%10 ? ' '+a[x%10] : '')
    return a[Math.floor(x/100)] + ' Hundred' + (x%100 ? ' '+hw(x%100) : '')
  }
  let r = ''
  if (n>=10000000){ r+=hw(Math.floor(n/10000000))+' Crore '; n%=10000000 }
  if (n>=100000)  { r+=hw(Math.floor(n/100000))  +' Lakh ';  n%=100000  }
  if (n>=1000)    { r+=hw(Math.floor(n/1000))    +' Thousand '; n%=1000  }
  if (n>0) r+=hw(n)
  return r.trim()
}

export function fmtINR(n) {
  return 'Rs.' + (n || 0).toLocaleString('en-IN', { maximumFractionDigits: 2 })
}

export function fmtDate(dateStr) {
  if (!dateStr) return '—'
  return new Date(dateStr).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })
}

export async function generateAndShareImage({ buyer, phone, address, date, items, gstEnabled, toWords, fmtINR }) {
  const html2canvas = (await import('html2canvas')).default

  const totAmt = items.reduce((s, i) => s + i.amount, 0)
  const totCFT = items.reduce((s, i) => s + i.cft, 0)
  const gst = gstEnabled ? totAmt * 0.18 : 0
  const grand = totAmt + gst
  const dateStr = date ? new Date(date).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric'}) : ''

  const rowsHTML = items.map((it, i) => `
    <tr style="background:${i%2===0?'#FDF6EE':'#FFFFFF'};">
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;text-align:center;color:#5C2E0A;font-weight:600;">${i+1}</td>
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;font-weight:600;color:#1a1a1a;">${it.wood}</td>
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;color:#4a3020;white-space:nowrap;font-size:12px;">${it.L}ft &times; ${it.W}&quot; &times; ${it.T}&quot;</td>
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;text-align:center;">${it.N}</td>
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;text-align:center;">${it.cft.toFixed(3)}</td>
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;text-align:right;white-space:nowrap;">Rs.${it.rate.toLocaleString('en-IN')}</td>
      <td style="padding:9px 10px;border-bottom:1px solid #EDD9B8;text-align:right;font-weight:700;color:#2C6E3A;white-space:nowrap;">Rs.${it.amount.toLocaleString('en-IN',{maximumFractionDigits:2})}</td>
    </tr>`).join('')

  const buyerBlock = (buyer||phone||address||dateStr) ? `
    <div style="padding:16px 22px;border-bottom:2px solid #EDD9B8;display:flex;flex-wrap:wrap;gap:14px;background:#FFFAF4;">
      ${buyer   ? `<div><div style="font-size:10px;font-weight:700;color:#9a7a5a;text-transform:uppercase;margin-bottom:3px;">Buyer</div><div style="font-size:15px;font-weight:700;">${buyer}</div></div>` : ''}
      ${phone   ? `<div><div style="font-size:10px;font-weight:700;color:#9a7a5a;text-transform:uppercase;margin-bottom:3px;">Phone</div><div style="font-size:15px;font-weight:600;">${phone}</div></div>` : ''}
      ${address ? `<div><div style="font-size:10px;font-weight:700;color:#9a7a5a;text-transform:uppercase;margin-bottom:3px;">Address</div><div style="font-size:15px;font-weight:600;">${address}</div></div>` : ''}
      ${dateStr ? `<div><div style="font-size:10px;font-weight:700;color:#9a7a5a;text-transform:uppercase;margin-bottom:3px;">Date</div><div style="font-size:15px;font-weight:600;">${dateStr}</div></div>` : ''}
    </div>` : ''

  const html = `
    <div style="background:#FFFAF4;overflow:hidden;font-family:Arial,sans-serif;">
      <div style="background:#2C1810;padding:18px 22px;display:flex;align-items:center;gap:14px;">
        <div style="width:44px;height:44px;border-radius:50%;background:#C9813A;display:flex;align-items:center;justify-content:center;font-size:22px;">🪵</div>
        <div><div style="color:#F8F0E3;font-size:22px;font-weight:800;">TIMBER BILL</div><div style="color:#C9A96E;font-size:11px;margin-top:3px;">ESTIMATE</div></div>
      </div>
      ${buyerBlock}
      <div style="padding:16px 22px 0;">
        <table style="width:100%;border-collapse:collapse;font-size:13px;">
          <thead><tr style="background:#3E1E08;">
            <th style="padding:10px;color:#F8F0E3;font-size:11px;">SR</th>
            <th style="padding:10px;color:#F8F0E3;text-align:left;font-size:11px;">WOOD</th>
            <th style="padding:10px;color:#F8F0E3;text-align:left;font-size:11px;">SIZE</th>
            <th style="padding:10px;color:#F8F0E3;font-size:11px;">NOS</th>
            <th style="padding:10px;color:#F8F0E3;font-size:11px;">CFT</th>
            <th style="padding:10px;color:#F8F0E3;text-align:right;font-size:11px;">RATE</th>
            <th style="padding:10px;color:#F8F0E3;text-align:right;font-size:11px;">AMOUNT</th>
          </tr></thead>
          <tbody>${rowsHTML}
            <tr style="background:#F8F0E3;">
              <td colspan="4" style="padding:9px 10px;font-weight:700;color:#5C2E0A;font-size:12px;border-top:2px solid #C9813A;">Total CFT</td>
              <td style="padding:9px 10px;text-align:center;font-weight:700;color:#5C2E0A;border-top:2px solid #C9813A;">${totCFT.toFixed(3)}</td>
              <td colspan="2" style="border-top:2px solid #C9813A;"></td>
            </tr>
          </tbody>
        </table>
      </div>
      <div style="margin:16px 22px 0;">
        <div style="display:flex;justify-content:space-between;padding:10px 16px;background:#F8F0E3;border-radius:8px 8px 0 0;border:1px solid #EDD9B8;border-bottom:none;">
          <span style="font-size:13px;color:#5C2E0A;font-weight:600;">Subtotal</span>
          <span style="font-size:14px;font-weight:700;">Rs.${totAmt.toLocaleString('en-IN',{maximumFractionDigits:2})}</span>
        </div>
        ${gstEnabled ? `<div style="display:flex;justify-content:space-between;padding:10px 16px;background:#FDF6EE;border:1px solid #EDD9B8;border-top:1px dashed #C9813A;border-bottom:none;">
          <span style="font-size:13px;color:#7a5a30;font-weight:600;">GST (18%)</span>
          <span style="font-size:14px;font-weight:700;color:#7a5a30;">Rs.${gst.toLocaleString('en-IN',{maximumFractionDigits:2})}</span>
        </div>` : ''}
        <div style="display:flex;justify-content:space-between;align-items:center;padding:14px 16px;background:#2C6E3A;border-radius:${gstEnabled?'0 0 12px 12px':'8px'};">
          <div>
            <div style="color:#a8d5b0;font-size:10px;font-weight:700;text-transform:uppercase;margin-bottom:3px;">Grand Total${gstEnabled?' (incl. GST)':''}</div>
            <div style="color:rgba(255,255,255,.7);font-size:10px;">${toWords(Math.round(grand))} Rupees Only</div>
          </div>
          <div style="color:#fff;font-size:22px;font-weight:800;white-space:nowrap;">Rs.${grand.toLocaleString('en-IN',{maximumFractionDigits:2})}</div>
        </div>
      </div>
      <div style="background:#2C1810;padding:12px 22px;margin-top:16px;display:flex;justify-content:space-between;">
        <span style="color:#C9A96E;font-size:11px;">Prices valid for 7 days</span>
        <span style="color:#8a6a4a;font-size:10px;">TIMBER BILL</span>
      </div>
    </div>`

  const wrap = document.createElement('div')
  wrap.style.cssText = 'position:fixed;left:-9999px;top:0;width:520px;font-family:Arial,sans-serif;'
  wrap.innerHTML = html
  document.body.appendChild(wrap)

  const canvas = await html2canvas(wrap, { scale: 3, useCORS: true, backgroundColor: '#FFFAF4', logging: false, windowWidth: 520 })
  document.body.removeChild(wrap)

  const jpegUrl = canvas.toDataURL('image/jpeg', 0.97)
  const res = await fetch(jpegUrl)
  const blob = await res.blob()
  const fname = 'Timber_Bill_' + (buyer?.replace(/\s+/g,'_') || 'Estimate') + '.jpg'
  const file = new File([blob], fname, { type: 'image/jpeg' })

  if (navigator.canShare && navigator.canShare({ files: [file] })) {
    await navigator.share({ files: [file], title: 'TIMBER BILL' })
  } else {
    const a = document.createElement('a'); a.href = jpegUrl; a.download = fname; a.click()
  }

  return { totAmt, totCFT }
}
